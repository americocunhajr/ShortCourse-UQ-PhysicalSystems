% -----------------------------------------------------------------
%  main_harmonic_oscillator.m
% -----------------------------------------------------------------
%  programmer: Diego Matos Silva Lopes
%              diego.matos@uerj.br
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
%  
% =================================================================

clear all
close all
clc

% -----------------------------------------------------------------
disp('=====================================================================');
disp(' Harmonic oscillator routine that calculate the dynamics and plot it ');
disp('=====================================================================');

% ===============================================================
% Harmonic oscillator
% m*x" + c*x' + k*x = f*cos(w*t) 
% ===============================================================

% Parameters of the oscillator
m = 1.0;  % mass
c = 0.2;  % damping
k = 2.0;  % stifness
f = 2.5;  % force intensity
w = 1.5;  % frequency

% Initial Condition
IC = [1; 0];

% Interval time to integrate the dynamics
t0 = 0;
tf = 50;
t_int = 0.1;
tspan = [t0:t_int:tf];

% Integration of the harmonic dynamics
[t,dyn] = harmonic_ODE45(m,c,k,f,w,IC,tspan);

% Compute the acceleration
acc = -c/m*dyn(:,2) -k/m*dyn(:,1) + f*cos(w*t);

disp('  -- Loading plot --  ');

% Plot parameters
% ----------------------------------------------------

subplot(3,1,1);
x = t;
y1 = dyn(:,1);
plot(x,y1,'LineWidth',1.5,'Color','r')
title('Displacement','FontSize',12,'FontName','Helvetica');
labX = xlabel('time','FontSize',9,'FontName','Helvetica');
labY = ylabel('m','FontSize',9,'FontName','Helvetica');

subplot(3,1,2)
y2 = dyn(:,2);
plot(x,y2,'LineWidth',1.5,'Color','g')
title('Velocity','FontSize',12,'FontName','Helvetica');
labX = xlabel('time','FontSize',9,'FontName','Helvetica');
labY = ylabel('m/s','FontSize',9,'FontName','Helvetica');

subplot(3,1,3)
y3 = acc;
plot(x,y3,'LineWidth',1.5,'Color','b')
title('Acceleration','FontSize',12,'FontName','Helvetica');
labX = xlabel('time','FontSize',9,'FontName','Helvetica');
labY = ylabel('m/s^2','FontSize',9,'FontName','Helvetica');

print(gcf,'Harmonic_dynamics','-dpdf','-r300','-bestfit');