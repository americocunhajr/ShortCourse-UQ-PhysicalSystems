% -----------------------------------------------------------------
%  model_larsonmiller.m
% ----------------------------------------------------------------- 
%  programmer: Americo Cunha
%              americo.cunha@uerj.br
%
%  last update: August 4, 2021
% -----------------------------------------------------------------
%  Function to compute rupture time for a material due to creep.
% -----------------------------------------------------------------
%  Input:
%  X     - data structure with the model parameters
%  X.T   - temperature (�C)
%  X.C   - fitting constant
%  X.PML - Larson-Miller parameter
%
%  Output:
%  QoI - rupture time (s)
% -----------------------------------------------------------------
function QoI = model_larsonmiller(X)

    % model parameters
	T   = X.T;   % temperature
	C   = X.C;   % fitting constant
    PLM = X.PML; % Larson-Miller parameter

    % time of rupture (s)
    tR = 10.^(PLM./T - C);

    % quantify of interest
    QoI = tR;
end
% -----------------------------------------------------------------