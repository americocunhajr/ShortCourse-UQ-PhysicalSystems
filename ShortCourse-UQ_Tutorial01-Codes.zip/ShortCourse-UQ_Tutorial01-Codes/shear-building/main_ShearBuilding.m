% -----------------------------------------------------------------
%  main_ShearBuilding.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This main file run the natural frequency (Hz) for
%  a Shear Building structure.
% -----------------------------------------------------------------

clear all
close all
clc

% ----------------------------------------------------------------

disp('---  defining model parameters ---');

% Physical parameters
% columns of first floor:
X.E1 = 200e9;   % Young's modulus - ASTM A36 (Pa)
X.b1 = 60e-3;   % width column (m)
X.h1 = 1e-3;    % thickness column (m)
X.L1 = 300e-3;  % length column (m)

% columns of second floor:
X.E2 = 200e9;   % Young's modulus - ASTM A36 (Pa)
X.b2 = 60e-3;   % width column (m)
X.h2 = 1e-3;    % thickness column (m)
X.L2 = 300e-3;  % length column (m)

% columns of third floor:
X.E3 = 200e9;   % Young's modulus - ASTM A36 (Pa)
X.b3 = 60e-3;   % width column (m)
X.h3 = 1e-3;    % thickness column (m)
X.L3 = 300e-3;  % length column (m)

% mass of floor (kg)
X.m1 = 0.5;
X.m2 = 0.5;
X.m3 = 0.5;

% ----------------------------------------------------------------

disp('                ...               ');
disp('---         processing         ---');

% Quantity of interest: time-displacement
QoI = model_ShearBuilding(X);

% ----------------------------------------------------------------

disp('                ...               ');
disp('---         displaying         ---');
disp('                                  '); 

fprintf('fn_1 = %.2f Hz \n', QoI(1))
fprintf('fn_2 = %.2f Hz \n', QoI(2))
fprintf('fn_3 = %.2f Hz \n', QoI(3))

disp('                                  '); 
% ----------------------------------------------------------------

disp('                ...               ');
disp('---    successfully finished   ---');