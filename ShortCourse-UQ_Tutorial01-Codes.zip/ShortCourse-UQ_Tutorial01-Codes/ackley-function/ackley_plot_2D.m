% ----------------------------------------------------------------- 
%  programmer: Marcos Vinicius Issa
%              marcos.issa@uerj.br
%
%  last update: August 08, 2021
% -----------------------------------------------------------------


function ackley_plot_2D(x1min,x1max,x2min,x2max,a,b)

% Contour Plot

hold on
    
    [x1, x2] = meshgrid (x1min:0.01:x1max,x2min:0.01:x2max);
    
    %Ackley Function
    J = -a.*exp(-b.*sqrt(0.5.*(x1.^2 + x2.^2))) - ...
        exp(0.5.*(cos(2.*pi.*x1)+cos(2.*pi.*x2))) + a + exp(1);
    
    mesh(x1,x2,J);
    
    xlabel('\it{x_1}','FontSize',20); ylabel('\it{x_2}','FontSize',20);
    zlabel('$f(x)$','Interpreter','latex','FontSize',20);
    
    
    set(gca,'FontSize',20)
    
    az = 45;
    el = 15;
    view(az, el);

hold off