% -----------------------------------------------------------------
%  main_steadyBurgers.m
% -----------------------------------------------------------------
%
% This is a main file for the steady (time-independent) viscous Burgers 
% equation:
%
%   nu * u_xx - u * u_x = 0 in ]0,1[
%   u(0) =  1
%   u(1) = -1
%
% where u is the fluid velocity and nu is kinematic viscosity.
%
% This equation has the analytical solution:
%
%   u(x) = -alpha * tanh ( alpha*(x - 0.5) / (2*nu))
%
% where the alpha constant is given by the transcendental equation:
%
%   alpha * tanh ( alpha / (4*nu) ) = 1
%
% This code uses model_burgers.m to compute the transcendental
% equation from the analytical solution of steady Burgers equation.
%
% Input:
%   param: model parameters and initial conditions
%   xspan: plot interval         
%
% Output:
%   figure(1): velocity solution - inplace figure
%   burgers_results.png: saves the figure(1)
% -----------------------------------------------------------
% programmers: Rachel Lucena
%              rachel.lucena@gmail.com 
%
% last update: August 10, 2021
% -----------------------------------------------------------

clc
clear
close all

% -----------------------------------------------------------  

% kinematic viscosity of fluid
param.nu = 1/10;

% initial condition to the transcendental equation 
param.IC = 0;

% -----------------------------------------------------------
% space interval of analysis
   x0 = 0;                          % left endpoint
   x1 = 1;                          % right endpoint
   npoints = 201;                   % number of points
   xspan = linspace(x0,x1,npoints);	% interval of analysis

%% Solving the analytical solution
QoI = model_burgers(param,xspan);

%% Recovering the result
ux = QoI;               % fluid velocity

%% Plotting the velocity
figure(1)
hold on
fig1(1) = plot(xspan,ux);
hold off

% plot labels
filename_fig1 = (['Steady-state Burgers equation - nu = ',num2str(param.nu)]);
title(filename_fig1);
xlabel('x');
ylabel('velocity - u(x)');

% set plot settings
set(gca,'FontSize',18);
set(fig1,{'Color'},{'b'});
set(fig1,{'LineWidth'},{2});

% legend
%leg = {'Velocity';};
%legend(fig1,leg,'FontSize',12,'location','northeast');

% axis limits
xlim([x0 x1]);
ylim([min(ux) max(ux)]);

% saving
set(gcf,'renderermode','manual', 'render','zbuffer');
saveas(gcf,'burgers_results.png')

% -----------------------------------------------------------

