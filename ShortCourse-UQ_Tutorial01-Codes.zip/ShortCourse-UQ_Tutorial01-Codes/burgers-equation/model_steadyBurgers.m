% -----------------------------------------------------------------
%  model_steadyBurgers.m
% -----------------------------------------------------------------
%  programmer: Rachel Lucena
%              rachel.lucena@gmail.com
%
%  last update: August 10, 2021
% -----------------------------------------------------------------
% Function to compute the analytical solution of steady-state 
% Burgers equation.
% -----------------------------------------------------------------
% Input:
%   param.nu    = kinematic viscosity of fluid
%   param.IC    = initial condition
%   xspan       = plot interval 
%
% Output:
%   QoI: quantity of interest (fluid velocity)
% -----------------------------------------------------------------

% -----------------------------------------------------------------
function QoI = model_steadyBurgers(param,xspan)

% kinematic viscosity of fluid
nu = param.nu;

% initial condition
IC = param.IC;

% defines the transcendental equation
myfun1 = @(x,nu) (1 - x*tanh(0.25*x/nu));

% creates a function of the transcendental equation
fun1 = @(x) myfun1(x,nu);

% finds the alpha constant
alpha = fzero(fun1,IC);

% defines the analytical solution
myfun2 = @(x,alpha,nu) (-alpha*tanh(alpha*(x-0.5)/2/nu));

% creates a function of the analytical solution
fun2 = @(x) myfun2(x,alpha,nu);

% output 
QoI = fun2(xspan);

end