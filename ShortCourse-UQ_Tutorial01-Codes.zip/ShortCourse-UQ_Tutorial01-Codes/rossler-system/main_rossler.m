% -----------------------------------------------------------------
%  main_rossler.m
% -----------------------------------------------------------------
%  programmer: Diego Matos Silva Lopes
%              diego.matos@uerj.br
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
%  
% =================================================================

clear all
close all
clc

% -----------------------------------------------------------------
disp('====================================================================');
disp('   Rossler routine that calculate the dynamics and plot it          ');
disp('====================================================================');

% ===============================================================
% Rossler Equation
% x' = -y - z
% y' = x + alpha*y
% z' = beta + z(x - gamma)
% ===============================================================

% Parameters of the Rossler dynamics
alpha = 0.1;
beta = 0.1;
gamma = 14.0;

% Initial Condition
IC = [-8; 8; 0];

% Interval time to integrate the dynamics
t0 = 0;
tf = 100;
t_int = 0.01;
tspan = [t0:t_int:tf];

% Integration of the Rossler dynamics
[t,dyn] = rossler_ODE45(alpha,beta,gamma,IC,tspan);

disp('  -- Loading plot --  ');

% Plot parameters
% ---------------------------------------------------
Nbegin = 1;
Njump  = 2;
Nend   = length(tspan);
xlab   = 'x';
ylab   = 'y';
zlab   = 'z';
gtitle = 'Rossler attractor';
Q1 = dyn(:,1);
Q2 = dyn(:,2);
Q3 = dyn(:,3);
xmin   = min(Q1(Nbegin:Nend));
xmax   = max(Q1(Nbegin:Nend));
ymin   = min(Q2(Nbegin:Nend));
ymax   = max(Q2(Nbegin:Nend));
zmin   = min(Q3(Nbegin:Nend));
zmax   = max(Q3(Nbegin:Nend));
gname  = ['Rossler_atractor3d'];
flag   = 'eps';

% Plot function
fig = plot_3d_atractor1(Q1(Nbegin:Njump:Nend),...
                          Q2(Nbegin:Njump:Nend),...
                          Q3(Nbegin:Njump:Nend),...
                          t(Nbegin:Njump:Nend),...
                          gtitle,xlab,ylab,zlab,...
                          xmin,xmax,ymin,ymax,zmin,zmax,gname,flag);

disp('          ...               ');
disp('  -- successfully finished --  ');