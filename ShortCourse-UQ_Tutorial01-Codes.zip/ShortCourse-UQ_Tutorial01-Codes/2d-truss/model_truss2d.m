% ----------------------------------------------------------------- 
%  programmer: Marcos Vinicius Issa
%              marcos.issa@uerj.br
%
%  last update: August 08, 2021
% -----------------------------------------------------------------

function model_truss2d(P1,P2);

% ...........................................................
% define physical parameters
% ...........................................................


% truss geometric dimensions (m)
p = 25.4e-3;
l1 = 360*p; % 1st length
l2 = 360*p; % 2nd length
h  = 360*p; % heigth

%bars nominal thickness (m)

A(1) = 6500e-6;
A(2) = 6500e-6;
A(3) = 6500e-6;
A(4) = 6500e-6;
A(5) = 6500e-6;
A(6) = 6500e-6;
A(7) = 6500e-6;
A(8) = 6500e-6;
A(9) = 6500e-6;
A(10) = 6500e-6;

% vertical loads (N)
P1 = - P1;
P2 = - P2;


% mass density (kg/m^3)
lbin3 = 27679.905;
rho = 0.1*lbin3;

% elastic modulus (Pa)
%10^6 psi = 6,9e9 
%E = 10e6 psi 
E = 69e9;

% yield strength (Pa)
ksi = 6894757.3;
SY_1 = 25*ksi;
SY_2 = 75*ksi;

% physical parameters vector
phys_param = [A E rho SY_1 SY_2 l1 l2 h P1 P2];

% 2D finite element mesh
% ...........................................................

% mesh points in global coordinates (Nnodes x 2)
XY_Mesh = [ (l1+l2)  h;
             (l1+l2) 0;
                 l1  h;
                  l1 0;
                  0 l1;
                  0 0];
% ...........................................................


% finite element pointers
% ...........................................................

% global coordinates of element nodes (Nelem x Nlnodes)
GlobalNodeID = [3 5;
                1 3;
                4 6;
                2 4;
                3 4;
                1 2;
                4 5;
                3 6;
                2 3;
                1 4];
                
% global coordinates of element DoFs (Nelem x Nldofs)
GlobalDoFID = [5 6  9  10;
               1 2  5  6;
               7 8  11 12;
               3 4  7  8;
               5 6  7  8;
               1 2  3  4;
               7 8  9  10;
               5 6  11 12;
               3 4  5  6;
               1 2  7  8];

% number of elements and number of local nodes
[Nelem,Nlnodes] = size(GlobalNodeID);

% number of nodes
Nnodes = size(XY_Mesh,1);

% number of local DoFs
Nldofs = size(GlobalDoFID,2);

% number of DoFs
Ndofs = 2*Nnodes;

% Diriclet boundary condition DoFs
bc_dofs  = [9 10 11 12];

% number of Diriclet boundary conditions
Nbcdofs = size(bc_dofs,2);

% vertical loads DoFs
load_dofs  = [4 8];

% vertical loads magnitudes vector
load_forces = [P1 P2];
% ...........................................................


% assembly global stiffness matrix and force vector
% ...........................................................
    % preallocate memory for global stiffness matrix
	K = zeros(Ndofs,Ndofs);
    
    % preallocate memory for global force vector
	f = zeros(Ndofs,1);
	
	% compute global stiffness matrix and force vector
    for iele=1:Nelem
        
        % compute local stiffness matrix and local force vector
		% physical parameters
        A   = phys_param(1:10); % cross-section area (m^2)
        E   = phys_param(11); % elastic modulus (N/m^2)
    
        % mesh points in local coordinates
        x1 = XY_Mesh(GlobalNodeID(iele,1),1);
        y1 = XY_Mesh(GlobalNodeID(iele,1),2);
        x2 = XY_Mesh(GlobalNodeID(iele,2),1);
        y2 = XY_Mesh(GlobalNodeID(iele,2),2);
    
        % compute element size
        Le = sqrt((x2-x1)^2+(y2-y1)^2);
    
        % trigonometric relations 
        cos0 = (x2-x1)/Le;
        sin0 = (y2-y1)/Le;
    
        % local stiffness matrix
            Ke = (E*A(iele)/Le)*[ cos0*cos0  cos0*sin0 -cos0*cos0 -cos0*sin0; 
                    cos0*sin0  sin0*sin0 -cos0*sin0 -sin0*sin0;
                   -cos0*cos0 -cos0*sin0  cos0*cos0  cos0*sin0;
                   -cos0*sin0 -sin0*sin0  cos0*sin0  sin0*sin0];

        % preallocate memory for local force vector
            fe = zeros(Nldofs,1);
    
		% assembly global stiffness matrix and global force vector
            for ildof=1:Nldofs
            
			% line global index
			igdof = GlobalDoFID(iele,ildof);
			
                for jldof=1:Nldofs
                
				% column global index
				jgdof = GlobalDoFID(iele,jldof);
				
				% global stiffness matrix
				K(igdof,jgdof) = K(igdof,jgdof) + Ke(ildof,jldof);
               
                end
			
			% global force vector
			f(igdof,1) = f(igdof,1) + fe(ildof,1);
            
            end
    end
    
    % ensure the stiffness matrix symmetry
    K = 0.5*(K+K');

% apply boundary conditions
% -----------------------------------------------------------

% Diriclet boundary conditions
      K(bc_dofs,:) = zeros(Nbcdofs,Ndofs);
      K(:,bc_dofs) = zeros(Ndofs,Nbcdofs);
K(bc_dofs,bc_dofs) = eye(Nbcdofs,Nbcdofs);
      F(bc_dofs,1) = 0.0;


% external loads
F(load_dofs,1) = load_forces;


% displacement vector
Udisp = K\F;

% -----------------------------------------------------------
% post processing
% -----------------------------------------------------------
% post_Truss2D
% -----------------------------------------------------------
% drawing displacements
%------------------------------------------------------------
xx = XY_Mesh(:,1);
yy = XY_Mesh(:,2);

us = 1:2:2*Nnodes-1;
vs = 2:2:2*Nnodes;

figure('DefaultAxesFontSize',10)
%L=xx(2)-xx(1);
%L=node(2,1)-node(1,1);
XX=Udisp(us);YY=Udisp(vs);
UNodes = sqrt(XX.^2+YY.^2);
dispNorm=max(sqrt(XX.^2+YY.^2));
%scaleFact=dispNorm;
scaleFact = 1.5*100*dispNorm;
clf
hold on
patch('Faces',GlobalNodeID,'Vertices',XY_Mesh,...
    'EdgeColor','blue','FaceColor','none','LineWidth',3);
patch('Faces',GlobalNodeID,'Vertices',(XY_Mesh+scaleFact*[XX YY]),...
    'EdgeColor','red','FaceColor','none','LineStyle','--','LineWidth',1.5);

xlabel('\bf{lenght (m)}'); ylabel('\bf{height (m)}');

disp(' ');
disp(' --- Displacements (mm)');
UNodes_plot = 1:Nnodes;
[UNodes_plot',UNodes*1000]'

end
