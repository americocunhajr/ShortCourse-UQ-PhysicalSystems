% -----------------------------------------------------------------
%  model_sir.m
% -----------------------------------------------------------------
%  programmer: Rachel Lucena
%              rachel.lucena@gmail.com
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
% Function to compute the system of ODEs for the SIR epidemic model.
% -----------------------------------------------------------------
% Input:
%   param.N     = population size   (number of individuals)
%   param.beta  = transmission rate (days^-1)
%   param.gamma = recovery rate     (days^-1)
%   param.IC    = initial condition vector 
%   tspan = integration parameter   
%
% Output:
%   QoI: quantity of interest (state rate of change and time interval)
% -----------------------------------------------------------------

% -----------------------------------------------------------------
%% Function to solve the ODE system
function QoI = model_sir(param,tspan)
% Initial conditions
IC = param.IC;

% ODE solver Runge-Kutta45
[time, y] = ode45(@(t,y)rhs_sir(y,param),tspan,IC);

% output of function
QoI = [y time];

end
% -----------------------------------------------------------------
%% Function to define the ODE system
function dydt = rhs_sir(y,param)
% Model parameters: param = [N beta gamma]
N     = param.N;      % population size   (number of individuals)
beta  = param.beta;   % transmission rate (days^-1)
gamma = param.gamma;  % recovery rate     (days^-1)

[S I R] = deal(y(1),y(2),y(3));

% state equations
dSdt = - beta*S.*(I/N);
dIdt = beta*S.*(I/N) - gamma*I;
dRdt = gamma*I;

% system of ODEs
dydt = [dSdt; dIdt; dRdt];
end