% -----------------------------------------------------------------
%  model_cobb_douglas.m
% -----------------------------------------------------------------
%  programmer: Bruna Pavlack
%              bruna.pavlack@ifms.edu.br
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
% This function computes the first derivative of the 
% Cobb–Douglas production function
% -----------------------------------------------------------------
%
%  ================================================================
%  Input:
%  L     - labour input (person-hours worked in a year or 365.25 days)
%  K0    - capital input (a measure of all machinery, equipment, 
%  and buildings)
%  alpha - output elasticities of capital
%  beta  - output elasticities of labor
%  
%  ================================================================
%  Output:
%  cobb  - first derivative of the Cobb–Douglas production function
% -----------------------------------------------------------------

function cobb = model_cobb_douglas(K0, alpha, beta)
    
    % Cobb–Douglas production function: f is total production (the real 
    % value of all goods produced in a year or 365.25 days).
    
    syms L
    f = K0^(alpha)*L^(beta);

    % First derivative of the Cobb–Douglas production function
    cobb = diff(f, L)
end
% -----------------------------------------------------------------
