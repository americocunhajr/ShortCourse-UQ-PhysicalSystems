% -----------------------------------------------------------------
%  main_cobb_douglas.m
% -----------------------------------------------------------------
%  programmer: Bruna Pavlack
%              bruna.pavlack@ifms.edu.br
%
%  last update: August 9, 2021
% -----------------------------------------------------------------
%  This main file executes the Cobb–Douglas production function plot
%  and its first derivative with one symbolic variable.
% -----------------------------------------------------------------

clear all
close all
clc

% -----------------------------------------------------------------
disp('====================================================================');
disp('   Cobb-Douglas production function plot and its first derivative   ');
disp('====================================================================');

% Parameters

K0    = 1;      % capital input
alpha = 0.5;    % output elasticities of capital
beta  = 0.5;    % output elasticities of labor


syms L

% Cobb–Douglas production function
f = K0^(alpha)*L^(beta);

% First derivative of the Cobb–Douglas production function
cobb = model_cobb_douglas(K0, alpha, beta);

disp('  -- Loading plot --  ');

% Plots of functions with one symbolic variable
figure();
hold on;
fplot(f, [0.2, 3],'LineWidth',[3])
fplot(cobb, [0.2, 3],'LineWidth',[3])
title({'Concave Y, with K=1, beta=0.5 and alpha=0.5'},'FontSize',22)
ylabel({'First derivative is slope=Y increase or decrease'},'FontSize',16)
xlabel('Current level of Labor', 'FontSize',16)
legend(['Y'], ['first Derivative'], 'Location','SE','FontSize',16 );
grid on

disp('          ...               ');
disp('  -- successfully finished --  ');