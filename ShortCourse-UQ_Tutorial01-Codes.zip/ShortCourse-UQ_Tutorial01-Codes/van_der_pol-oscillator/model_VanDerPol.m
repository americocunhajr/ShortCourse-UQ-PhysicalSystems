% -----------------------------------------------------------------
%  model_VanDerPol.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This function computes the quantity of interest (QoI) for
%  a given Van Der Pol oscillator.
% -----------------------------------------------------------------
%
%  ================================================================
%  Input:
%  X    - model parameters
%  X.mu - rate damping
% 
%  P       - model hyperparameters
%  P.tspan - time of integration
%  P.Ic    - initial conditions
%
%  ================================================================
%  Output:
%  QoI - quantity of interest
%  QoI - displacement
%
% -----------------------------------------------------------------

% -----------------------------------------------------------------
function QoI = model_VanDerPol(X,P)
    
    % Physical parameters
    mu    = X.mu;
    
    % Initial conditions
    IC    = P.IC;

    % Time of integration
    tspan = P.tspan;

    % Equation of motion
    dXdT = @(t,x)[x(2); 
                  mu*(1-x(1)^2)*x(2) - x(1)];
	
	% ODE solver optional parameters
    opt = odeset('RelTol',1.0e-9,'AbsTol',1.0e-9);
    
	% Integration of equation of motion
    [time,x] = ode45(dXdT,tspan,IC,opt);
    
    % Quantity of interest: displacement
    QoI   = x(:,1);
end
% -----------------------------------------------------------------
