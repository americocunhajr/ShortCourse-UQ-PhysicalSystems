% -----------------------------------------------------------------
%  main_VanDerPol.m
% -----------------------------------------------------------------
%  programmer: João Pedro Norenberg
%              jp.norenberg@unesp.br
%
%  last update: August 6, 2021
% -----------------------------------------------------------------
%  This main file run the quantity of interest (QoI) for
%  a given Van Der Pol oscillator.
% -----------------------------------------------------------------

clear all
close all
clc

% ----------------------------------------------------------------

disp('---  defining model parameters ---');
    
% Physical parameters
X.mu   = 3.0;

% Initial conditions
P.IC = [1,0];       % [inital displacement, initial velocity]

% Time of integration
ti = 0;             % initial time
tf = 30;            % final time
dt = 0.01;          % increment time
P.tspan = ti:dt:tf; % vector time

% ----------------------------------------------------------------

disp('                ...               ');
disp('---         integration        ---');

% Quantity of interest: time-displacement
QoI = model_VanDerPol(X,P);

% ----------------------------------------------------------------

disp('                ...               ');
disp('---           plotting         ---');

% plotting time-response
plot(P.tspan,QoI,'linewidth',2)

set(gca,'FontName','Arial','FontSize',15,'linewidth',1.2);
set(gcf,'color','w');
xlabel(        'time'      ,'FontSize',15,'FontWeight','bold')
ylabel('electrical current','FontSize',15,'FontWeight','bold')

saveas(gcf,'current_VanDerPol','png')

% ----------------------------------------------------------------

disp('                ...               ');
disp('---    successfully finished   ---');