clc; clear all; close all;
a = 2; b=5; Ns = 1000;

rng_stream = RandStream('mt19937ar','Seed',30081984);
RandStream.setGlobalStream(rng_stream); % Matlab 2013

X     = betarnd(a,b,Ns,1);
Nbins = round(sqrt(Ns));
Nksd  = round(0.1*Ns);

[X_bins,X_freq,X_area] = randvar_pdf(X,Nbins);
[X_ksd ,X_supp       ] = ksdensity(X);

figure(1)
bar(X_bins,X_freq,1.0);
hold on
plot(X_supp,X_ksd,'r','linewidth',3)
xlim([0 1]);
hold off