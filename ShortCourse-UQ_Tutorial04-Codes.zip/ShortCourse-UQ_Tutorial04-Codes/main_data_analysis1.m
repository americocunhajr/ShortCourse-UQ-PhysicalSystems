clc; clear all; close all;
a = 2; b=5; Ns = 1000;

X      = betarnd(a,b,Ns,1);
mu     = mean(X)
sigma2 = var(X)
sigma  = std(X)
gamma1 = skewness(X)
beta2  = kurtosis(X)

figure(1)
plot(1:Ns,X,'o')
ylim([0 1]);

figure(2)
hist(X)
xlim([0 1]);