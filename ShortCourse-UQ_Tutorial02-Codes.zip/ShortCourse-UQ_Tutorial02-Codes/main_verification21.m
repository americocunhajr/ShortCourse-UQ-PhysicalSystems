clc; clear all; close all;
m = 1.0; ksi = 0.1; wn = 4.0; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0; t0 = 0.0; t1 = 10.0; N = 3000;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [0; (f/m)*sin(w*t)];

[time,phi] = euler(dphidt,[x0;v0],t0,t1,N);

plot(time,phi(1,:),'LineWidth',3);