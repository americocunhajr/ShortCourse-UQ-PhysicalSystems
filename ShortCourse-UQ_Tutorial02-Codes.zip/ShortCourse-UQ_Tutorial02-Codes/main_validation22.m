m = 1.0; ksi = 0.05; wn = 3.2; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi + [0; (f/m)*sin(w*t)];
[t_uncal,phi_uncal] = euler(dphidt,[x0;v0],t0,t1,N);

figure(3)
plot(t_uncal,phi_uncal(1,:),'b','LineWidth',3);
hold on
plot(t_exp1,x_exp1,'xr','LineWidth',3);
plot(t_exp1,x_exp1,'--r','LineWidth',0.3);
hold off
axis([t0 t1 -2 2])
set(gca,'fontsize',18)
legend('Uncalibrated','Experiment 1')