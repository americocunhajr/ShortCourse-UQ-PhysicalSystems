clc; clear all; close all;
m = 1.0; ksi = 0.1; wn = 4.0; f = 10.0; w = 5.0;
x0 = 1.0; v0 = 0.0; t0 = 0.0; t1 = 10.0; N = 5000;

dphidt=@(t,phi)[0 1; -wn^2 -2*ksi*wn]*phi ...
             + [-2*sin(t); ...
             cos(t)+2*ksi*wn*sin(t)+wn^2*cos(t)];

[time,phi] = euler(dphidt,[x0;v0],t0,t1,N);

x_true  = cos(time);

subplot(2,1,1) 
plot(time,phi(1,:),'b','LineWidth',3);
legend('Euler')
subplot(2,1,2) 
plot(time,x_true,  'g','LineWidth',3);
legend('True')