
function [time,phi] = euler(rhs,phi0,t0,t1,N)

dt       = (t1-t0)/N;
time     = zeros(1,N+1);
phi      = zeros(length(phi0),N+1);
phi(:,1) = phi0;

for n = 1:N
  time(1,n+1) = time(1,n) + dt;
  phi(:,n+1) =  phi(:,n) + dt*rhs(t0,phi0);
end

return
