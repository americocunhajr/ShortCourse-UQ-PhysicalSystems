clc; clear; close all


Ns = 1e5;

ymin = 0.0; ymax = 2*pi;

Y  = ymin + (ymax-ymin)*rand(Ns,1);
hY = (ymax-ymin)*(sin(Y).^2);

alpha_hat = cumsum(hY)./(1:Ns)';
error     = abs(pi-alpha_hat);

semilogy(1:Ns,error,'x')
title(' Monte Carlo integration','FontSize',20)
set(gca,'fontsize',18)
xlabel('number of samples')
ylabel('error')
grid