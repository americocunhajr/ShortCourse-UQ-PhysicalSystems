clear all
close all
clc


Ns   = 20;
xmin = 0.0;
xmax = 1.0;
ymin = 0.0;
ymax = 1.0;

mu    = 0.5;
delta = 0.5;
sigma = mu*delta;

% uniform sample
Xu = rand(Ns);
Yu = rand(Ns);

% normal sample
Xn = mu + sigma*randn(Ns);
Yn = mu + sigma*randn(Ns);

% gamma sample
Xg = gamrnd(1.0/delta^2,mu*delta^2,Ns);
Yg = gamrnd(1.0/delta^2,mu*delta^2,Ns);

% Chi-squared  sample
Xc2 = chi2rnd(mu,Ns);
Yc2 = chi2rnd(mu,Ns);


% plot uniform sampling
figure(1)
plot(Xu,Yu,'.b');
axis([xmin xmax ymin ymax]);
title(' Uniform Distribution','FontSize',20)
set(gca,'fontsize',18)

% plot normal sampling
figure(2)
plot(Xn,Yn,'.r');
axis([xmin xmax ymin ymax]);
title(' Normal Distribution','FontSize',20)
set(gca,'fontsize',18)

% plot gamma sampling
figure(3)
plot(Xg,Yg,'.g');
axis([xmin xmax ymin ymax]);
title(' Gamma Distribution','FontSize',20)
set(gca,'fontsize',18)

% plot Chi-squared  sample
figure(4)
plot(Xc2,Yc2,'.m');
axis([xmin xmax ymin ymax]);
title(' Chi-squared Distribution','FontSize',20)
set(gca,'fontsize',18)


