clear; close all; clc
% random number generator (fix the seed for reproducibility)
rng_stream = RandStream('mt19937ar','Seed',30081984);
RandStream.setGlobalStream(rng_stream);
Ns = 5000;

muR = 0.5; sigmaR = 0.1; nuR = muR*(1-muR)/(sigmaR^2)-1;
a = muR*nuR; b = (1-muR)*nuR; muH = 1.0; 
R = betarnd(a,b,Ns,1); H = exprnd(muH,Ns,1);

V_cone      = (1/3)*pi*R.^2.*H;
[bins,freq] = randvar_pdf(V_cone,round(sqrt(Ns)));
alpha_2     = cumsum(V_cone.^2)'./(1:Ns);

figure(1)
gplotmatrix([R,H]);

figure(2)
plot(V_cone,'o'); ylim([0 5])

figure(3)
bar(bins,freq);
xlim([0 4]); ylim([0 5])

figure(4)
plot(1:Ns,alpha_2,'LineWidth',2)