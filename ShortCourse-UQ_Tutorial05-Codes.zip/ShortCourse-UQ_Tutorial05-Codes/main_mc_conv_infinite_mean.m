clc; clear; close all;

Ns = 10^3;
X1 = randn(Ns,1); X2 = randn(Ns,1); X3 = randn(Ns,1);
Z1 = 1./(1+X1); Z2 = 1./(1+X2); Z3 = 1./(1+X3);

meanZ1 = mean(Z1)
meanZ2 = mean(Z2)
meanZ3 = mean(Z3)

figure(1)
plot(1:Ns,X1,'xb',1:Ns,X2,'xg',1:Ns,X3,'xm','LineWidth',1)
xlabel('index'); ylabel('X'); xlim([1,Ns]); ylim([-4 4]);

figure(2)
plot(1:Ns,Z1,'xb',1:Ns,Z2,'xg',1:Ns,Z3,'xm','LineWidth',1)
hold on
plot([1 Ns],[meanZ1 meanZ1],'b-', 'LineWidth', 4);
plot([1 Ns],[meanZ2 meanZ2],'g-', 'LineWidth', 4);
plot([1 Ns],[meanZ3 meanZ3],'m-', 'LineWidth', 4);
hold off
xlabel('index'); ylabel('Y'); xlim([1,Ns]); ylim([-2000 12000]);
